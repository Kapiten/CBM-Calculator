package com.cbm.android.cbmcalculator.historian;

public class Historian {
    
}

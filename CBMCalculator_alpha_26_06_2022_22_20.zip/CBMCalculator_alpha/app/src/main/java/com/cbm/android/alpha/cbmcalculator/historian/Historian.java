package com.cbm.android.alpha.cbmcalculator.historian;

public class Historian {
    
}
